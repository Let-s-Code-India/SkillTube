SkillTube backend bundle (temporary file).
Contains: 6 SQL files, 4 Edge Functions, backup workflow.
Copilot: unzip at the repo root (files already have their final paths), verify, then delete this zip and this README.
